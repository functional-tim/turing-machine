# Changelog for turing-machine
## 0.1.2.0
- Renaming of the library to libturing-machine
- Correcting of Version numbers

## 0.1.1.0
- Fixing the "-p" Option
- Cleaning up some Layout bits in Main.hs

## 0.1.0.0
- Cleanup and first real Version
- Adding of Documentation
- Commenting of Lib.hs
- Filling in README.md

## 0.0.0.0
- No more track record

## Unreleased changes
- AppImage is planned
- Better Documentation
- Commenting of Main.hs

# Changelog for turing-machine
1.0.0.0:
- Cleanup and first real Version
- Adding of Documentation
- Commenting of Lib.hs
- Filling in README.md


## Unreleased changes
- AppImage is planned
- Better Documentation
- Commenting of Main.hs
